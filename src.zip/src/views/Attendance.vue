<template>
    <div class="frames-frame19">
      <img alt="Rectangle151335" src class="frames-rectangle15" />
      <span class="frames-text"><span>Dashboard</span></span>
      <img alt="Rectangle191335" src class="frames-rectangle19" />
      <img alt="Rectangle211335" src class="frames-rectangle21" />
      <img alt="Rectangle201335" src class="frames-rectangle20" />
      <img alt="Rectangle181335" src class="frames-rectangle18" />
      <span class="frames-text002"><span>Calendar</span></span>
      <img alt="Rectangle171335" src class="frames-rectangle17" />
      <img alt="Rectangle161335" src class="frames-rectangle16" />
      <span class="frames-text004"><span>Admin</span></span>
      <img alt="logokse31335" src class="frames-logokse3" />
      <img alt="image21335" src class="frames-image2" />
      <span class="frames-text006"><span>Staff ID: 123</span></span>
      <span class="frames-text008"><span>Weclome, Admin!</span></span>
      <span class="frames-text010">
        <span>
          Department: HR
          <span v-html="rawprji"></span>
        </span>
      </span>
      <img alt="image33057" src class="frames-image3" />
    </div>
  </template>
<script>
export default {
  name: 'attendance',
  data() {
    return {
      rawprji: ' ',
    }
  },
  metaInfo: {
    title: 'exported project',
  },
}
</script>