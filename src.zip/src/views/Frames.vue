<template>
  <div class="frames-container">
    <div class="frames-frame19">
      <img alt="Rectangle151335" src class="frames-rectangle15" />
      <span class="frames-text"><span>Dashboard</span></span>
      <img alt="Rectangle191335" src class="frames-rectangle19" />
      <img alt="Rectangle211335" src class="frames-rectangle21" />
      <img alt="Rectangle201335" src class="frames-rectangle20" />
      <img alt="Rectangle181335" src class="frames-rectangle18" />
      <span class="frames-text002"><span>Calendar</span></span>
      <img alt="Rectangle171335" src class="frames-rectangle17" />
      <img alt="Rectangle161335" src class="frames-rectangle16" />
      <span class="frames-text004"><span>Admin</span></span>
      <img alt="logokse31335" src class="frames-logokse3" />
      <img alt="image21335" src class="frames-image2" />
      <span class="frames-text006"><span>Staff ID: 123</span></span>
      <span class="frames-text008"><span>Weclome, Admin!</span></span>
      <span class="frames-text010">
        <span>
          Department: HR
          <span v-html="rawprji"></span>
        </span>
      </span>
      <img alt="image33057" src class="frames-image3" />
    </div>


    
    <div class="frames-frame21">
      <img src alt="Rectangle151336" class="frames-rectangle151" />
      <span class="frames-text012"><span>Calendar</span></span>
      <img src alt="Rectangle191336" class="frames-rectangle191" />
      <img src alt="Rectangle211336" class="frames-rectangle211" />
      <img src alt="Rectangle201336" class="frames-rectangle201" />
      <img src alt="Rectangle181336" class="frames-rectangle181" />
      <span class="frames-text014"><span>Calendar</span></span>
      <img src alt="Rectangle171336" class="frames-rectangle171" />
      <span class="frames-text016"><span>Home</span></span>
      <img src alt="Rectangle161336" class="frames-rectangle161" />
      <img src alt="logokse31336" class="frames-logokse31" />
      <img src alt="image21336" class="frames-image21" />
      <span class="frames-text018"><span>Admin</span></span>
      <img src alt="Rectangle351689" class="frames-rectangle35" />
      <img src alt="Rectangle401689" class="frames-rectangle40" />
    </div>
    <div class="frames-frame23">
      <img src alt="Rectangle151336" class="frames-rectangle152" />
      <span class="frames-text020"><span>Date: 3/7/2023</span></span>
      <span class="frames-text022"><span>Daily view:</span></span>
      <span class="frames-text024"><span>Attendance</span></span>
      <img src alt="logokse31336" class="frames-logokse32" />
      <img src alt="Rectangle191336" class="frames-rectangle192" />
      <img src alt="Rectangle211336" class="frames-rectangle212" />
      <img src alt="Rectangle201336" class="frames-rectangle202" />
      <img src alt="Rectangle181336" class="frames-rectangle182" />
      <img src alt="Rectangle171336" class="frames-rectangle172" />
      <span class="frames-text026"><span>Home</span></span>
      <img src alt="Rectangle161336" class="frames-rectangle162" />
      <span class="frames-text028"><span>Calendar</span></span>
      <img src alt="logokse41336" class="frames-logokse4" />
      <img src alt="image21336" class="frames-image22" />
      <span class="frames-text030"><span>Admin</span></span>
    </div>
    <div class="frames-frame30">
      <img src alt="Rectangle422561" class="frames-rectangle42" />
      <span class="frames-text032"><span>July 2023</span></span>
      <span class="frames-text034"><span>Monthly view:</span></span>
      <img src alt="Rectangle152561" class="frames-rectangle153" />
      <span class="frames-text036"><span>Calendar</span></span>
      <img src alt="Rectangle192561" class="frames-rectangle193" />
      <img src alt="Rectangle212561" class="frames-rectangle213" />
      <img src alt="Rectangle202561" class="frames-rectangle203" />
      <img src alt="Rectangle182561" class="frames-rectangle183" />
      <span class="frames-text038"><span>Calendar</span></span>
      <img src alt="Rectangle172561" class="frames-rectangle173" />
      <span class="frames-text040"><span>Home</span></span>
      <img src alt="Rectangle162561" class="frames-rectangle163" />
      <img src alt="logokse32561" class="frames-logokse33" />
      <img src alt="image22561" class="frames-image23" />
      <span class="frames-text042"><span>Admin</span></span>
      <img src alt="Rectangle432561" class="frames-rectangle43" />
      <div class="frames-table">
        <div class="frames-table1">
          <div class="frames-table2">
            <div class="frames-row">
              <div class="frames-frame29"></div>
              <div class="frames-frame42">
                <span class="frames-text044"><span>Mr. A</span></span>
              </div>
              <div class="frames-frame41">
                <span class="frames-text046"><span>Mr. B</span></span>
              </div>
              <div class="frames-frame40">
                <span class="frames-text048"><span>Mr. C</span></span>
              </div>
              <div class="frames-frame39">
                <span class="frames-text050"><span>Mr. D</span></span>
              </div>
              <div class="frames-frame43">
                <span class="frames-text052"><span>Mr. E</span></span>
              </div>
              <div class="frames-frame44">
                <span class="frames-text054"><span>Mr. F</span></span>
              </div>
              <div class="frames-frame38">
                <span class="frames-text056"><span>Mr. X</span></span>
              </div>
            </div>
            <div class="frames-row01">
              <div class="frames-frame2901">
                <span class="frames-text058"><span>Day 1</span></span>
              </div>
              <div class="frames-frame4201">
                <span class="frames-text060">V</span>
              </div>
              <div class="frames-frame4101">
                <span class="frames-text061">X</span>
              </div>
              <div class="frames-frame4001">
                <span class="frames-text062">V</span>
              </div>
              <div class="frames-frame3901">
                <span class="frames-text063">X</span>
              </div>
              <div class="frames-frame4301">
                <span class="frames-text064">X</span>
              </div>
              <div class="frames-frame4401">
                <span class="frames-text065">X</span>
              </div>
              <div class="frames-frame3801">
                <span class="frames-text066"><span>...</span></span>
              </div>
            </div>
            <div class="frames-row02">
              <div class="frames-frame2902">
                <span class="frames-text068"><span>Day 2</span></span>
              </div>
              <div class="frames-frame4202">
                <span class="frames-text070">V</span>
              </div>
              <div class="frames-frame4102">
                <span class="frames-text071">X</span>
              </div>
              <div class="frames-frame4002">
                <span class="frames-text072">V</span>
              </div>
              <div class="frames-frame3902">
                <span class="frames-text073">X</span>
              </div>
              <div class="frames-frame4302">
                <span class="frames-text074">X</span>
              </div>
              <div class="frames-frame4402">
                <span class="frames-text075">X</span>
              </div>
              <div class="frames-frame3802">
                <span class="frames-text076"><span>...</span></span>
              </div>
            </div>
            <div class="frames-row03">
              <div class="frames-frame2903">
                <span class="frames-text078"><span>Day 3</span></span>
              </div>
              <div class="frames-frame4203">
                <span class="frames-text080">V</span>
              </div>
              <div class="frames-frame4103">
                <span class="frames-text081">X</span>
              </div>
              <div class="frames-frame4003">
                <span class="frames-text082">V</span>
              </div>
              <div class="frames-frame3903">
                <span class="frames-text083">X</span>
              </div>
              <div class="frames-frame4303">
                <span class="frames-text084">X</span>
              </div>
              <div class="frames-frame4403">
                <span class="frames-text085">X</span>
              </div>
              <div class="frames-frame3803">
                <span class="frames-text086"><span>...</span></span>
              </div>
            </div>
            <div class="frames-row04">
              <div class="frames-frame2904">
                <span class="frames-text088"><span>...</span></span>
              </div>
              <div class="frames-frame4204">
                <span class="frames-text090">V</span>
              </div>
              <div class="frames-frame4104">
                <span class="frames-text091">X</span>
              </div>
              <div class="frames-frame4004">
                <span class="frames-text092">V</span>
              </div>
              <div class="frames-frame3904">
                <span class="frames-text093">X</span>
              </div>
              <div class="frames-frame4304">
                <span class="frames-text094">X</span>
              </div>
              <div class="frames-frame4404">
                <span class="frames-text095">X</span>
              </div>
              <div class="frames-frame3804">
                <span class="frames-text096"><span>...</span></span>
              </div>
            </div>
            <div class="frames-row05">
              <div class="frames-frame2905">
                <span class="frames-text098"><span>...</span></span>
              </div>
              <div class="frames-frame4205">
                <span class="frames-text100">V</span>
              </div>
              <div class="frames-frame4105">
                <span class="frames-text101">X</span>
              </div>
              <div class="frames-frame4005">
                <span class="frames-text102">V</span>
              </div>
              <div class="frames-frame3905">
                <span class="frames-text103">X</span>
              </div>
              <div class="frames-frame4305">
                <span class="frames-text104">X</span>
              </div>
              <div class="frames-frame4405">
                <span class="frames-text105">X</span>
              </div>
              <div class="frames-frame3805">
                <span class="frames-text106"><span>...</span></span>
              </div>
            </div>
            <div class="frames-row06">
              <div class="frames-frame2906">
                <span class="frames-text108"><span>...</span></span>
              </div>
              <div class="frames-frame4206">
                <span class="frames-text110">V</span>
              </div>
              <div class="frames-frame4106">
                <span class="frames-text111">X</span>
              </div>
              <div class="frames-frame4006">
                <span class="frames-text112">V</span>
              </div>
              <div class="frames-frame3906">
                <span class="frames-text113">X</span>
              </div>
              <div class="frames-frame4306">
                <span class="frames-text114">X</span>
              </div>
              <div class="frames-frame4406">
                <span class="frames-text115">X</span>
              </div>
              <div class="frames-frame3806">
                <span class="frames-text116"><span>...</span></span>
              </div>
            </div>
            <div class="frames-row07">
              <div class="frames-frame2907">
                <span class="frames-text118"><span>Day 31</span></span>
              </div>
              <div class="frames-frame4207">
                <span class="frames-text120">V</span>
              </div>
              <div class="frames-frame4107">
                <span class="frames-text121">X</span>
              </div>
              <div class="frames-frame4007">
                <span class="frames-text122">V</span>
              </div>
              <div class="frames-frame3907">
                <span class="frames-text123">X</span>
              </div>
              <div class="frames-frame4307">
                <span class="frames-text124">X</span>
              </div>
              <div class="frames-frame4407">
                <span class="frames-text125">X</span>
              </div>
              <div class="frames-frame3807">
                <span class="frames-text126"><span>...</span></span>
              </div>
            </div>
            <div class="frames-row08">
              <div class="frames-frame2908">
                <span class="frames-text128"><span>Presents</span></span>
              </div>
              <div class="frames-frame4208">
                <span class="frames-text130">V</span>
              </div>
              <div class="frames-frame4108">
                <span class="frames-text131">X</span>
              </div>
              <div class="frames-frame4008">
                <span class="frames-text132">V</span>
              </div>
              <div class="frames-frame3908">
                <span class="frames-text133">X</span>
              </div>
              <div class="frames-frame4308">
                <span class="frames-text134">X</span>
              </div>
              <div class="frames-frame4408">
                <span class="frames-text135">X</span>
              </div>
              <div class="frames-frame3808">
                <span class="frames-text136"><span>...</span></span>
              </div>
            </div>
            <div class="frames-row09">
              <div class="frames-frame2909">
                <span class="frames-text138"><span>Absents</span></span>
              </div>
              <div class="frames-frame4209">
                <span class="frames-text140">V</span>
              </div>
              <div class="frames-frame4109">
                <span class="frames-text141">X</span>
              </div>
              <div class="frames-frame4009">
                <span class="frames-text142">V</span>
              </div>
              <div class="frames-frame3909">
                <span class="frames-text143">X</span>
              </div>
              <div class="frames-frame4309">
                <span class="frames-text144">X</span>
              </div>
              <div class="frames-frame4409">
                <span class="frames-text145">X</span>
              </div>
              <div class="frames-frame3809">
                <span class="frames-text146"><span>...</span></span>
              </div>
            </div>
            <div class="frames-row10">
              <div class="frames-frame2910">
                <span class="frames-text148"><span>Total</span></span>
              </div>
              <div class="frames-frame4210">
                <span class="frames-text150">V</span>
              </div>
              <div class="frames-frame4110">
                <span class="frames-text151">X</span>
              </div>
              <div class="frames-frame4010">
                <span class="frames-text152">V</span>
              </div>
              <div class="frames-frame3910">
                <span class="frames-text153">X</span>
              </div>
              <div class="frames-frame4310">
                <span class="frames-text154">X</span>
              </div>
              <div class="frames-frame4410">
                <span class="frames-text155">X</span>
              </div>
              <div class="frames-frame3810">
                <span class="frames-text156"><span>...</span></span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="frames-frame24">
      <img src alt="image11336" class="frames-image1" />
      <img src alt="Rectangle71336" class="frames-rectangle7" />
      <span class="frames-text158"><span>Sign in</span></span>
      <img
        src="/external/line11336-k9i.svg"
        alt="Line11336"
        class="frames-line1"
      />
      <img
        src="/external/line21336-1i5s.svg"
        alt="Line21336"
        class="frames-line2"
      />
      <span class="frames-text160"><span>Username</span></span>
      <span class="frames-text162"><span>Password</span></span>
      <img src alt="Rectangle91336" class="frames-rectangle9" />
      <span class="frames-text164"><span>Sign in</span></span>
      <img src alt="logokse21336" class="frames-logokse2" />
    </div>
  </div>
</template>

<script>
export default {
  name: 'Frames',
  data() {
    return {
      rawprji: ' ',
    }
  },
  metaInfo: {
    title: 'exported project',
  },
}
</script>

<style scoped>
.frames-container {
  width: 1920px;
  display: flex;
  overflow: auto;
  min-height: 100vh;
  align-items: center;
  flex-direction: column;
}
.frames-frame19 {
  width: 100%;
  height: 1080px;
  display: flex;
  overflow: hidden;
  position: relative;
  align-items: flex-start;
  flex-shrink: 0;
  background-color: rgba(240, 240, 240, 1);
}
.frames-rectangle15 {
  top: 225px;
  left: 100px;
  width: 1720px;
  height: 855px;
  position: absolute;
}
.frames-text {
  top: 255px;
  left: 159px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 99px;
  font-style: Medium;
  text-align: left;
  font-family: Inter;
  font-weight: 500;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-rectangle19 {
  top: 0px;
  left: 1820px;
  width: 100px;
  height: 225px;
  position: absolute;
}
.frames-rectangle21 {
  top: 0px;
  left: 1593px;
  width: 227px;
  height: 225px;
  position: absolute;
}
.frames-rectangle20 {
  top: 0px;
  left: 0px;
  width: 100px;
  height: 225px;
  position: absolute;
}
.frames-rectangle18 {
  top: 0px;
  left: 1240px;
  width: 353px;
  height: 225px;
  position: absolute;
}
.frames-text002 {
  top: 78px;
  left: 1289px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 55px;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-rectangle17 {
  top: 0px;
  left: 853px;
  width: 387px;
  height: 225px;
  position: absolute;
}
.frames-rectangle16 {
  top: 0px;
  left: 596px;
  width: 257px;
  height: 225px;
  position: absolute;
}
.frames-text004 {
  top: 78px;
  left: 1576px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 55px;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-logokse3 {
  top: 0px;
  left: 100px;
  width: 496px;
  height: 225px;
  position: absolute;
}
.frames-image2 {
  top: 66px;
  left: 1753px;
  width: 41px;
  height: 92px;
  position: absolute;
}
.frames-text006 {
  top: 508px;
  left: 417px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 55px;
  font-style: Medium;
  text-align: left;
  font-family: Inter;
  font-weight: 500;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-text008 {
  top: 405px;
  left: 417px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 55px;
  font-style: Medium;
  text-align: left;
  font-family: Inter;
  font-weight: 500;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-text010 {
  top: 599px;
  left: 417px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 55px;
  font-style: Medium;
  text-align: left;
  font-family: Inter;
  font-weight: 500;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-image3 {
  top: 405px;
  left: 159px;
  width: 209px;
  height: 237px;
  position: absolute;
  border-radius: 30px;
}
.frames-frame21 {
  width: 100%;
  height: 1080px;
  display: flex;
  overflow: hidden;
  position: relative;
  align-items: flex-start;
  flex-shrink: 0;
  background-color: rgba(240, 240, 240, 1);
}
.frames-rectangle151 {
  top: 225px;
  left: 100px;
  width: 1720px;
  height: 855px;
  position: absolute;
}
.frames-text012 {
  top: 243px;
  left: 142px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 99px;
  font-style: Medium;
  text-align: left;
  font-family: Inter;
  font-weight: 500;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-rectangle191 {
  top: 0px;
  left: 1820px;
  width: 100px;
  height: 225px;
  position: absolute;
}
.frames-rectangle211 {
  top: 0px;
  left: 1593px;
  width: 227px;
  height: 225px;
  position: absolute;
}
.frames-rectangle201 {
  top: 0px;
  left: 0px;
  width: 100px;
  height: 225px;
  position: absolute;
}
.frames-rectangle181 {
  top: 0px;
  left: 1240px;
  width: 353px;
  height: 225px;
  position: absolute;
}
.frames-text014 {
  top: 78px;
  left: 1289px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 55px;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-rectangle171 {
  top: 0px;
  left: 853px;
  width: 387px;
  height: 225px;
  position: absolute;
}
.frames-text016 {
  top: 79px;
  left: 1044px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 55px;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-rectangle161 {
  top: 0px;
  left: 596px;
  width: 257px;
  height: 225px;
  position: absolute;
}
.frames-logokse31 {
  top: 0px;
  left: 100px;
  width: 496px;
  height: 225px;
  position: absolute;
}
.frames-image21 {
  top: 66px;
  left: 1753px;
  width: 41px;
  height: 92px;
  position: absolute;
}
.frames-text018 {
  top: 78px;
  left: 1576px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 55px;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-rectangle35 {
  top: 580px;
  left: 100px;
  width: 50px;
  height: 100px;
  position: absolute;
}
.frames-rectangle40 {
  top: 580px;
  left: 348px;
  width: 50px;
  height: 100px;
  position: absolute;
}
.frames-frame23 {
  width: 100%;
  height: 1080px;
  display: flex;
  overflow: hidden;
  position: relative;
  align-items: flex-start;
  flex-shrink: 0;
  background-color: rgba(240, 240, 240, 1);
}
.frames-rectangle152 {
  top: 225px;
  left: 100px;
  width: 1717px;
  height: 855px;
  position: absolute;
}
.frames-text020 {
  top: 275px;
  left: 1474px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 40px;
  font-style: Medium;
  text-align: left;
  font-family: Inter;
  font-weight: 500;
  line-height: 150%;
  font-stretch: normal;
  text-decoration: none;
}
.frames-text022 {
  top: 275px;
  left: 1267px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 40px;
  font-style: Medium;
  text-align: left;
  font-family: Inter;
  font-weight: 500;
  line-height: 150%;
  font-stretch: normal;
  text-decoration: none;
}
.frames-text024 {
  top: 245px;
  left: 170px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 99px;
  font-style: Medium;
  text-align: left;
  font-family: Inter;
  font-weight: 500;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-logokse32 {
  top: 67px;
  left: -2463px;
  width: 496px;
  height: 225px;
  position: absolute;
}
.frames-rectangle192 {
  top: 0px;
  left: 1820px;
  width: 100px;
  height: 225px;
  position: absolute;
}
.frames-rectangle212 {
  top: 0px;
  left: 1593px;
  width: 227px;
  height: 225px;
  position: absolute;
}
.frames-rectangle202 {
  top: 0px;
  left: 0px;
  width: 100px;
  height: 225px;
  position: absolute;
}
.frames-rectangle182 {
  top: 0px;
  left: 1240px;
  width: 353px;
  height: 225px;
  position: absolute;
}
.frames-rectangle172 {
  top: 0px;
  left: 853px;
  width: 387px;
  height: 225px;
  position: absolute;
}
.frames-text026 {
  top: 79px;
  left: 1044px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 55px;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-rectangle162 {
  top: 0px;
  left: 596px;
  width: 257px;
  height: 225px;
  position: absolute;
}
.frames-text028 {
  top: 78px;
  left: 1289px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 55px;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-logokse4 {
  top: 0px;
  left: 100px;
  width: 496px;
  height: 225px;
  position: absolute;
}
.frames-image22 {
  top: 66px;
  left: 1753px;
  width: 41px;
  height: 92px;
  position: absolute;
}
.frames-text030 {
  top: 78px;
  left: 1576px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 55px;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame30 {
  width: 100%;
  height: 1080px;
  display: flex;
  overflow: hidden;
  position: relative;
  align-items: flex-start;
  flex-shrink: 0;
  background-color: rgba(240, 240, 240, 1);
}
.frames-rectangle42 {
  top: 225px;
  left: 100px;
  width: 1720px;
  height: 855px;
  position: absolute;
}
.frames-text032 {
  top: 273px;
  left: 1569px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 40px;
  font-style: Medium;
  text-align: left;
  font-family: Inter;
  font-weight: 500;
  line-height: 150%;
  font-stretch: normal;
  text-decoration: none;
}
.frames-text034 {
  top: 273px;
  left: 1301px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 40px;
  font-style: Medium;
  text-align: left;
  font-family: Inter;
  font-weight: 500;
  line-height: 150%;
  font-stretch: normal;
  text-decoration: none;
}
.frames-rectangle153 {
  top: 1148px;
  left: -658px;
  width: 1720px;
  height: 597px;
  position: absolute;
}
.frames-text036 {
  top: 243px;
  left: 134px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 99px;
  font-style: Medium;
  text-align: left;
  font-family: Inter;
  font-weight: 500;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-rectangle193 {
  top: 0px;
  left: 1820px;
  width: 100px;
  height: 225px;
  position: absolute;
}
.frames-rectangle213 {
  top: 0px;
  left: 1593px;
  width: 227px;
  height: 225px;
  position: absolute;
}
.frames-rectangle203 {
  top: 0px;
  left: 0px;
  width: 100px;
  height: 225px;
  position: absolute;
}
.frames-rectangle183 {
  top: 0px;
  left: 1240px;
  width: 353px;
  height: 225px;
  position: absolute;
}
.frames-text038 {
  top: 78px;
  left: 1289px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 55px;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-rectangle173 {
  top: 0px;
  left: 853px;
  width: 387px;
  height: 225px;
  position: absolute;
}
.frames-text040 {
  top: 79px;
  left: 1044px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 55px;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-rectangle163 {
  top: 0px;
  left: 596px;
  width: 257px;
  height: 225px;
  position: absolute;
}
.frames-logokse33 {
  top: 0px;
  left: 100px;
  width: 496px;
  height: 225px;
  position: absolute;
}
.frames-image23 {
  top: 66px;
  left: 1753px;
  width: 41px;
  height: 92px;
  position: absolute;
}
.frames-text042 {
  top: 78px;
  left: 1576px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 55px;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-rectangle43 {
  top: 363px;
  left: 100px;
  width: 1720px;
  height: 717px;
  position: absolute;
}
.frames-table {
  gap: 10px;
  top: 353px;
  left: 100px;
  width: 1720px;
  display: flex;
  padding: 10px 0;
  position: absolute;
  align-items: center;
  flex-shrink: 0;
  flex-direction: column;
  justify-content: center;
}
.frames-table1 {
  gap: 10px;
  height: 710px;
  display: flex;
  align-self: stretch;
  align-items: flex-start;
  flex-shrink: 0;
  flex-direction: column;
  background-color: rgba(255, 255, 255, 1);
}
.frames-table2 {
  gap: 22px;
  height: 690px;
  display: flex;
  align-self: stretch;
  align-items: flex-start;
  flex-shrink: 0;
  flex-direction: column;
}
.frames-row {
  gap: 5px;
  display: flex;
  align-self: stretch;
  align-items: flex-start;
  flex-shrink: 0;
  background-color: rgba(255, 165, 0, 1);
}
.frames-frame29 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 165, 0, 1);
}
.frames-frame42 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 165, 0, 1);
}
.frames-text044 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Semi Bold;
  text-align: center;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame41 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 165, 0, 1);
}
.frames-text046 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Semi Bold;
  text-align: center;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame40 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 165, 0, 1);
}
.frames-text048 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Semi Bold;
  text-align: center;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame39 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 165, 0, 1);
}
.frames-text050 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Semi Bold;
  text-align: center;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame43 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 165, 0, 1);
}
.frames-text052 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Semi Bold;
  text-align: center;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame44 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 165, 0, 1);
}
.frames-text054 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Semi Bold;
  text-align: center;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame38 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 165, 0, 1);
}
.frames-text056 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Semi Bold;
  text-align: center;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-row01 {
  gap: 5px;
  display: flex;
  align-self: stretch;
  align-items: flex-start;
  flex-shrink: 0;
  background-color: rgba(255, 255, 255, 1);
}
.frames-frame2901 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text058 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Semi Bold;
  text-align: center;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4201 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text060 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4101 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text061 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4001 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text062 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame3901 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text063 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4301 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text064 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4401 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text065 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame3801 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text066 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-row02 {
  gap: 5px;
  display: flex;
  align-self: stretch;
  align-items: flex-start;
  flex-shrink: 0;
  background-color: rgba(211, 211, 211, 1);
}
.frames-frame2902 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text068 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Semi Bold;
  text-align: center;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4202 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text070 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4102 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text071 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4002 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text072 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame3902 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text073 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4302 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text074 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4402 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text075 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame3802 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text076 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-row03 {
  gap: 5px;
  display: flex;
  align-self: stretch;
  align-items: flex-start;
  flex-shrink: 0;
  background-color: rgba(255, 255, 255, 1);
}
.frames-frame2903 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text078 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Semi Bold;
  text-align: center;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4203 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text080 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4103 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text081 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4003 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text082 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame3903 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text083 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4303 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text084 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4403 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text085 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame3803 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text086 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-row04 {
  gap: 5px;
  display: flex;
  align-self: stretch;
  align-items: flex-start;
  flex-shrink: 0;
  background-color: rgba(211, 211, 211, 1);
}
.frames-frame2904 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text088 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Semi Bold;
  text-align: center;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4204 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text090 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4104 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text091 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4004 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text092 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame3904 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text093 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4304 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text094 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4404 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text095 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame3804 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text096 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-row05 {
  gap: 5px;
  display: flex;
  align-self: stretch;
  align-items: flex-start;
  flex-shrink: 0;
  background-color: rgba(255, 255, 255, 1);
}
.frames-frame2905 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text098 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Semi Bold;
  text-align: center;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4205 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text100 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4105 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text101 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4005 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text102 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame3905 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text103 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4305 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text104 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4405 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text105 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame3805 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text106 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-row06 {
  gap: 5px;
  display: flex;
  align-self: stretch;
  align-items: flex-start;
  flex-shrink: 0;
  background-color: rgba(211, 211, 211, 1);
}
.frames-frame2906 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text108 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Semi Bold;
  text-align: center;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4206 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text110 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4106 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text111 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4006 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text112 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame3906 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text113 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4306 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text114 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4406 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text115 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame3806 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text116 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-row07 {
  gap: 5px;
  display: flex;
  align-self: stretch;
  align-items: flex-start;
  flex-shrink: 0;
  background-color: rgba(255, 255, 255, 1);
}
.frames-frame2907 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text118 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Semi Bold;
  text-align: center;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4207 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text120 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4107 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text121 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4007 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text122 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame3907 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text123 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4307 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text124 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4407 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text125 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame3807 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text126 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-row08 {
  gap: 5px;
  display: flex;
  align-self: stretch;
  align-items: flex-start;
  flex-shrink: 0;
  background-color: rgba(211, 211, 211, 1);
}
.frames-frame2908 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text128 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Semi Bold;
  text-align: center;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4208 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text130 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4108 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text131 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4008 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text132 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame3908 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text133 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4308 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text134 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4408 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text135 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame3808 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(211, 211, 211, 1);
}
.frames-text136 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-row09 {
  gap: 5px;
  display: flex;
  align-self: stretch;
  align-items: flex-start;
  flex-shrink: 0;
  background-color: rgba(255, 255, 255, 1);
}
.frames-frame2909 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text138 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Semi Bold;
  text-align: center;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4209 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text140 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4109 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text141 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4009 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text142 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame3909 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text143 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4309 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text144 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4409 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text145 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame3809 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 255, 255, 1);
}
.frames-text146 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-row10 {
  gap: 5px;
  display: flex;
  align-self: stretch;
  align-items: flex-start;
  flex-shrink: 0;
  background-color: rgba(255, 165, 0, 1);
}
.frames-frame2910 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 165, 0, 1);
}
.frames-text148 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Semi Bold;
  text-align: center;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4210 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 165, 0, 1);
}
.frames-text150 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4110 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 165, 0, 1);
}
.frames-text151 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4010 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 165, 0, 1);
}
.frames-text152 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame3910 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 165, 0, 1);
}
.frames-text153 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4310 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 165, 0, 1);
}
.frames-text154 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame4410 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 165, 0, 1);
}
.frames-text155 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame3810 {
  gap: 10px;
  display: flex;
  padding: 0 36px;
  overflow: hidden;
  flex-grow: 1;
  align-self: stretch;
  align-items: center;
  justify-content: center;
  background-color: rgba(255, 165, 0, 1);
}
.frames-text156 {
  color: rgba(0, 0, 0, 1);
  height: auto;
  font-size: 33px;
  font-style: Regular;
  text-align: center;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-frame24 {
  width: 100%;
  height: 1080px;
  display: flex;
  overflow: hidden;
  position: relative;
  align-items: flex-start;
  flex-shrink: 0;
  background-color: rgba(240, 240, 240, 1);
}
.frames-image1 {
  top: 0px;
  left: -20px;
  width: 1960px;
  height: 1080px;
  position: absolute;
}
.frames-rectangle7 {
  top: 3px;
  left: -69px;
  width: 750px;
  height: 1080px;
  position: absolute;
  border-radius: 56px;
}
.frames-text158 {
  top: 303px;
  left: 88px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 77px;
  font-style: Semi Bold;
  text-align: left;
  font-family: Inter;
  font-weight: 700;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-line1 {
  top: 543px;
  left: 88px;
  width: 500px;
  height: 1px;
  position: absolute;
}
.frames-line2 {
  top: 647px;
  left: 88px;
  width: 500px;
  height: 1px;
  position: absolute;
}
.frames-text160 {
  top: 466px;
  left: 88px;
  color: rgba(143, 134, 134, 1);
  height: auto;
  position: absolute;
  font-size: 55px;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-text162 {
  top: 579px;
  left: 88px;
  color: rgba(143, 134, 134, 1);
  height: auto;
  position: absolute;
  font-size: 55px;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-rectangle9 {
  top: 751px;
  left: 88px;
  width: 503px;
  height: 112px;
  position: absolute;
  border-radius: 100px;
}
.frames-text164 {
  top: 773px;
  left: 263px;
  color: rgba(0, 0, 0, 1);
  height: auto;
  position: absolute;
  font-size: 55px;
  font-style: Regular;
  text-align: left;
  font-family: Inter;
  font-weight: 400;
  line-height: normal;
  font-stretch: normal;
  text-decoration: none;
}
.frames-logokse2 {
  top: 69px;
  left: 88px;
  width: 336px;
  height: 164px;
  position: absolute;
}
</style>
