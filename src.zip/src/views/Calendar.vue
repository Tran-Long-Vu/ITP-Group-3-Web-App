<template>
<div class="frames-frame21">
    <img src alt="Rectangle151336" class="frames-rectangle151" />
    <span class="frames-text012"><span>Calendar</span></span>
    <img src alt="Rectangle191336" class="frames-rectangle191" />
    <img src alt="Rectangle211336" class="frames-rectangle211" />
    <img src alt="Rectangle201336" class="frames-rectangle201" />
    <img src alt="Rectangle181336" class="frames-rectangle181" />
    <span class="frames-text014"><span>Calendar</span></span>
    <img src alt="Rectangle171336" class="frames-rectangle171" />
    <span class="frames-text016"><span>Home</span></span>
    <img src alt="Rectangle161336" class="frames-rectangle161" />
    <img src alt="logokse31336" class="frames-logokse31" />
    <img src alt="image21336" class="frames-image21" />
    <span class="frames-text018"><span>Admin</span></span>
    <img src alt="Rectangle351689" class="frames-rectangle35" />
    <img src alt="Rectangle401689" class="frames-rectangle40" />
  </div>
</template>

<script>
export default {
  name: 'Caldendar',
  data() {
    return {
      rawprji: ' ',
    }
  },
  metaInfo: {
    title: 'KSE',
  },
}
</script>

