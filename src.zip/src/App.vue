<template>
  <div id="app">
    <nav class="navbar">
      <div class="navbar-logo">
        <img src="./assets/logo.jpg" alt="Logo">
      </div>
      <div class="navbar-links">
        <router-link to="/" class="nav-link">Home</router-link>
        <router-link to="/Calendar" class="nav-link">Calendar</router-link>
        <router-link to="/services" class="nav-link">User</router-link>
      </div>
    </nav>
    <div class="content">
      <div class="square">
        <router-view></router-view>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data(){
    return {
  name: "App",
  
    }
  }
};
</script>
<style>
  .navbar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    height: 80px;
    padding: 0 50px;
    background-color: #FFA500;
  }

  .navbar-logo img {
    height: 100px;
  }

  .navbar-links {
    display: flex;
    justify-content: flex-end;
    width: 50%;
  }

  .nav-link {
    color: #FFFFFF;
    font-size: 18px;
    margin-left: 20px;
    text-decoration: none;
    text-transform: uppercase;
    letter-spacing: 1px;
  }

  .nav-link:hover {
    text-decoration: underline;
  }

  .content {
    max-width: 1434px;
    height: 686px;
    margin: 40px auto 0;
    background-color: #f2f2f2;
  }
  .square {
    background-color: #D9D9D9;
    height: 50px;
    margin: 0 50px;
  }
</style>