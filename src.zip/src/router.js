import Vue from 'vue'
import Router from 'vue-router'
import Meta from 'vue-meta'

import Frames from './views/Frames.vue'
import Home from './views/Home.vue'
import Login from './views/Login.vue'
import Calendar from './views/Calendar.vue'
import Attendance from './views/Attendance.vue'
import './style.css'

Vue.use(Router)
Vue.use(Meta)
export default new Router({
  mode: 'history',
  routes: [
    {
      name: 'Frames',
      path: '/frames',
      component: Frames,
    },
    {
      name: 'Home',
      path: '/home',
      component: Home,
    },
    {
      name: 'Login',
      path: '/login',
      component: Login,
    },
    {
      name: 'Calendar',
      path: '/Calendar',
      component: Calendar,
    },
    {
      name: 'Attendance',
      path: '/attendance',
      component: Attendance,
    },
  ],
})